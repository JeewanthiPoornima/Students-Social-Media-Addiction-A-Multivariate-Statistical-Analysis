**Data Preprocessing Steps**


```R
# Install necessary packages
install.packages(c("factoextra","psych","qgraph","MASS","caret","biotools","pROC","CCA"))
```

    Installing packages into ‘/usr/local/lib/R/site-library’
    (as ‘lib’ is unspecified)
    
    also installing the dependencies ‘listenv’, ‘parallelly’, ‘future’, ‘globals’, ‘shape’, ‘future.apply’, ‘progressr’, ‘SQUAREM’, ‘locfit’, ‘ash’, ‘FNN’, ‘kernlab’, ‘mclust’, ‘multicool’, ‘pracma’, ‘diagram’, ‘lava’, ‘pcaPP’, ‘hdrcde’, ‘ks’, ‘bitops’, ‘prodlim’, ‘rainbow’, ‘RCurl’, ‘dotCall64’, ‘proxy’, ‘iterators’, ‘clock’, ‘gower’, ‘hardhat’, ‘ipred’, ‘sparsevctrs’, ‘timeDate’, ‘fds’, ‘deSolve’, ‘spam’, ‘maps’, ‘igraph’, ‘e1071’, ‘foreach’, ‘ModelMetrics’, ‘recipes’, ‘fda’, ‘fields’
    
    
    


```R
# Read your data
data <- read.csv("students_social_media_addiction.csv")

# Remove non-analytical ID field (Student_ID)
data <- subset(data, select = -Student_ID)

# Remove duplicate rows
data <- data[!duplicated(data), ]

# Remove rows with missing values
data <- na.omit(data)

# Separate variable names
numeric_vars <- names(data)[sapply(data, is.numeric)]
categorical_vars <- names(data)[sapply(data, function(x) is.factor(x) || is.character(x))]

# Create separate data frames
numeric_data <- data[, numeric_vars]
categorical_data <- data[, categorical_vars]


# Outlier detection and removal using z-score (for each numeric column)
zscore_outlier_removal <- function(df) {
  for (col in names(df)) {
    z <- abs((df[[col]] - mean(df[[col]], na.rm=TRUE)) / sd(df[[col]], na.rm=TRUE))
    df <- df[z < 3, ]
  }
  return(df)
}
numeric_data <- zscore_outlier_removal(numeric_data)

# Standardize the numeric data
numeric_data_scaled <- scale(numeric_data)
```

**Principal Component Analysis(PCA)**


```R
# Perform PCA
pca_result <- prcomp(numeric_data_scaled, center = TRUE, scale. = TRUE)

# Calculate explained variance
explained_var <- pca_result$sdev^2 / sum(pca_result$sdev^2)
explained_var_percent <- explained_var * 100

# Scree plot using ggplot2
library(ggplot2)
scree_df <- data.frame(
  PC = 1:length(explained_var_percent),
  ExplainedVariance = explained_var_percent
)

ggplot(scree_df, aes(x = PC, y = ExplainedVariance)) +
  geom_bar(stat = "identity", fill = "skyblue", alpha = 0.7) +
  geom_line(color = "red", size = 1) +
  geom_point(color = "red", size = 2) +
  # Add percentage labels above each bar
  geom_text(
    aes(label = paste0(round(ExplainedVariance, 1), "%")),vjust = -0.5,size = 4
  ) +
  labs(
    title = "Scree Plot: Explained Variance by PCA Components",x = "Principal Component",
    y = "Explained Variance (%)"
  ) +
  theme_minimal()

# Print the percentage for each PC (all PCs)
for (i in seq_along(explained_var_percent)) {
  cat("PC", i, "explains", round(explained_var_percent[i], 2), "% of the variance\n")
}

# Print total explained variance by first two components
total_var_2 <- sum(explained_var_percent[1:2])
cat("Total Explained Variance by First 2 Principal Components:", round(total_var_2, 1), "%\n\n")

# Print loadings for the first and second principal components
cat("PCA Component Loadings (PC1 and PC2):\n")
print(round(pca_result$rotation[, 1:2], 6))

# Extract eigenvalues from the PCA result
eigenvalues <- pca_result$sdev^2

# Select principal components with eigenvalues >= 0.7 (Jolliffe's method)
selected_pcs <- which(eigenvalues >= 0.7)

# Print the number of PCs to consider
cat("\nNumber of PCs to retain according to Jolliffe's method:", length(selected_pcs), "\n")
```

    PC 1 explains 71.72 % of the variance
    PC 2 explains 16.16 % of the variance
    PC 3 explains 6.71 % of the variance
    PC 4 explains 3.06 % of the variance
    PC 5 explains 1.71 % of the variance
    PC 6 explains 0.64 % of the variance
    Total Explained Variance by First 2 Principal Components: 87.9 %
    
    PCA Component Loadings (PC1 and PC2):
                                      PC1       PC2
    Age                          0.101610 -0.991884
    Avg_Daily_Usage_Hours       -0.439421 -0.094326
    Sleep_Hours_Per_Night        0.407594  0.072468
    Mental_Health_Score          0.455159  0.030981
    Conflicts_Over_Social_Media -0.451800 -0.001070
    Addicted_Score              -0.468144 -0.032500
    
    Number of PCs to retain according to Jolliffe's method: 2 
    


    
![png](output_4_1.png)
    



```R
library(factoextra)

# Biplot for the first two principal components (PC1 vs PC2)
fviz_pca_biplot(
  pca_result,repel = TRUE,col.var = "red",col.ind = "blue",pointshape = 21,fill.ind = "lightblue",addEllipses = TRUE,
  label = "var",title = "Biplot (PC1 vs PC2)"
)
```


    
![png](output_5_0.png)
    


**Factor Analysis(FA)**


```R
library(psych)

# Parallel analysis and scree plot for factor analysis
fa.parallel(numeric_data_scaled, fa = "fa", n.iter = 100)  # This gives both a scree plot and parallel analysis

# Run factor analysis with the suggested number of factors(2) and varimax rotation
fa_result <- fa(numeric_data_scaled, nfactors = 2, rotate = "varimax")

#Print the factor loadings
print(fa_result$loadings)

# Get the factor loadings matrix
loadings_matrix <- as.matrix(fa_result$loadings)

library(qgraph)
# Plot all loadings
qgraph.loadings(
  loadings_matrix,minimum = 0.01,cut = 0,vsize = c(8, 18),edge.labels = TRUE,layout = "tree",posCol = "forestgreen",negCol = "firebrick",borders = TRUE
)

```

    Parallel analysis suggests that the number of factors =  2  and the number of components =  NA 
    
    Loadings:
                                MR1    MR2   
    Age                         -0.163       
    Avg_Daily_Usage_Hours        0.639  0.601
    Sleep_Hours_Per_Night       -0.361 -0.930
    Mental_Health_Score         -0.843 -0.435
    Conflicts_Over_Social_Media  0.866  0.396
    Addicted_Score               0.860  0.485
    
                     MR1   MR2
    SS loadings    2.765 1.812
    Proportion Var 0.461 0.302
    Cumulative Var 0.461 0.763
    


    
![png](output_7_1.png)
    



    
![png](output_7_2.png)
    


**Discriminant** **analysis(DA)**


```R
library(MASS)
library(caret)
library(biotools)
library(pROC)

# Create binary outcome: High vs Low Addiction based on median
threshold <- median(data$Addicted_Score, na.rm = TRUE)
data$Addiction_Level <- ifelse(data$Addicted_Score > threshold, "High", "Low")
data$Addiction_Level <- as.factor(data$Addiction_Level)

# Select relevant numeric predictors
predictor_vars <- c("Age", "Avg_Daily_Usage_Hours", "Sleep_Hours_Per_Night",
                    "Mental_Health_Score", "Conflicts_Over_Social_Media")

set.seed(123)  # For reproducibility
train_index <- createDataPartition(data$Addiction_Level, p = 0.7, list = FALSE)
train_data <- data[train_index, ]
test_data  <- data[-train_index, ]

# Prepare matrix for Box's M test
train_predictors <- train_data[, predictor_vars]
train_group      <- train_data$Addiction_Level

# Box's M test for equality of covariance matrices
boxM_result <- boxM(train_predictors, train_group)
print(boxM_result)
# Interpretation:
# If p-value > 0.05, LDA is suitable.
# If p-value < 0.05, QDA is more appropriate.

# Extract p-value from Box's M test result
p_value <- boxM_result$p.value

# Print interpretation based on p-value
if (p_value > 0.05) {
  print("LDA is suitable because the covariance matrices are equal (p > 0.05).")
} else {
  print("QDA is more appropriate because the covariance matrices are different (p < 0.05).")
}

# Quadratic Discriminant Analysis (QDA)
qda_model <- qda(Addiction_Level ~ Age + Avg_Daily_Usage_Hours + Sleep_Hours_Per_Night +
                 Mental_Health_Score + Conflicts_Over_Social_Media, data = train_data)
qda_pred <- predict(qda_model, test_data)

# Confusion matrix for QDA (using caret for nice output)
conf_matrix <- confusionMatrix(qda_pred$class, test_data$Addiction_Level)
print(conf_matrix)

# Fourfold plot (heatmap) for confusion matrix
fourfoldplot(conf_matrix$table, color = c("red", "green"),
             main = "Confusion Matrix Heatmap (QDA)")

# Calculate accuracy
accuracy <- mean(qda_pred$class == test_data$Addiction_Level)
cat(sprintf("QDA Accuracy: %.2f%%\n", accuracy * 100))

# ROC Curve for QDA
roc_data <- roc(test_data$Addiction_Level, qda_pred$posterior[, "High"])
plot(roc_data, main = "ROC Curve for QDA", print.auc = TRUE)
```

    Loading required package: lattice
    
    ---
    biotools version 4.3
    
    Type 'citation("pROC")' for a citation.
    
    
    Attaching package: ‘pROC’
    
    
    The following objects are masked from ‘package:stats’:
    
        cov, smooth, var
    
    
    

    
    	Box's M-test for Homogeneity of Covariance Matrices
    
    data:  train_predictors
    Chi-Sq (approx.) = 173.8, df = 15, p-value < 2.2e-16
    
    [1] "QDA is more appropriate because the covariance matrices are different (p < 0.05)."
    Confusion Matrix and Statistics
    
              Reference
    Prediction High Low
          High   57   0
          Low     2 151
                                             
                   Accuracy : 0.9905         
                     95% CI : (0.966, 0.9988)
        No Information Rate : 0.719          
        P-Value [Acc > NIR] : <2e-16         
                                             
                      Kappa : 0.9762         
                                             
     Mcnemar's Test P-Value : 0.4795         
                                             
                Sensitivity : 0.9661         
                Specificity : 1.0000         
             Pos Pred Value : 1.0000         
             Neg Pred Value : 0.9869         
                 Prevalence : 0.2810         
             Detection Rate : 0.2714         
       Detection Prevalence : 0.2714         
          Balanced Accuracy : 0.9831         
                                             
           'Positive' Class : High           
                                             
    QDA Accuracy: 99.05%
    

    Setting levels: control = High, case = Low
    
    Setting direction: controls > cases
    
    


    
![png](output_9_3.png)
    



    
![png](output_9_4.png)
    


**Canonical** **Correlation** **Analysis(CCA)**


```R
#Load CCA package
library(CCA)

# Define and standardize variable sets
X <- scale(data[, c("Age", "Sleep_Hours_Per_Night", "Mental_Health_Score")])
Y <- scale(data[, c("Avg_Daily_Usage_Hours", "Conflicts_Over_Social_Media", "Addicted_Score")])

# Run CCA
cca_result <- cc(X, Y)
plt.cc(cca_result)

# Canonical correlations
cat("Canonical correlations:\n")
print(cca_result$cor)

# Canonical coefficients
cat("\nCanonical coefficients for X (Set 1):\n")
print(cca_result$xcoef)

cat("\nCanonical coefficients for Y (Set 2):\n")
print(cca_result$ycoef)
```

    Loading required package: fda
    
    Loading required package: splines
    
    Loading required package: fds
    
    Loading required package: rainbow
    
    Loading required package: pcaPP
    
    Loading required package: RCurl
    
    Loading required package: deSolve
    
    
    Attaching package: ‘fda’
    
    
    The following object is masked from ‘package:lattice’:
    
        melanoma
    
    
    The following object is masked from ‘package:graphics’:
    
        matplot
    
    
    The following object is masked from ‘package:datasets’:
    
        gait
    
    
    Loading required package: fields
    
    Loading required package: spam
    
    Spam version 2.11-1 (2025-01-20) is loaded.
    Type 'help( Spam)' or 'demo( spam)' for a short introduction 
    and overview of this package.
    Help for individual functions is also obtained by adding the
    suffix '.spam' to the function name, e.g. 'help( chol.spam)'.
    
    
    Attaching package: ‘spam’
    
    
    The following objects are masked from ‘package:base’:
    
        backsolve, forwardsolve
    
    
    Loading required package: viridisLite
    
    
    Try help(fields) to get started.
    
    
    Attaching package: ‘fields’
    
    
    The following object is masked from ‘package:psych’:
    
        describe
    
    
    

    Canonical correlations:
    [1] 0.95889071 0.43785432 0.04250247
    
    Canonical coefficients for X (Set 1):
                                  [,1]       [,2]       [,3]
    Age                   -0.006208925  0.2235212 -0.9883448
    Sleep_Hours_Per_Night -0.255527593 -1.3635898 -0.2828403
    Mental_Health_Score   -0.801667881  1.1040765  0.4048566
    
    Canonical coefficients for Y (Set 2):
                                       [,1]        [,2]       [,3]
    Avg_Daily_Usage_Hours        0.17640068  1.62488064  0.8014385
    Conflicts_Over_Social_Media -0.03844637 -1.58723513  2.3291114
    Addicted_Score               0.88442766  0.04307021 -2.8840595
    


    
![png](output_11_2.png)
    

